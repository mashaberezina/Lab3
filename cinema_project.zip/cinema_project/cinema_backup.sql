--
-- PostgreSQL database dump
--

\restrict DkWE9c7l4BY0FEev2jhph4kWGDGwiGwOB34G8s5Bacmnaqg62ecupzd61sNqbNa

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: log_changes(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.log_changes() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO Журнал_логов (Пользователь, Действие, Таблица, Дата_время, Старые_данные, Новые_данные)
    VALUES (current_user, TG_OP, TG_TABLE_NAME, NOW(),
            CASE WHEN TG_OP IN ('UPDATE', 'DELETE') THEN row_to_json(OLD)::TEXT ELSE NULL END,
            CASE WHEN TG_OP IN ('INSERT', 'UPDATE') THEN row_to_json(NEW)::TEXT ELSE NULL END);
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.log_changes() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bilet; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bilet (
    id_bileta integer NOT NULL,
    cena numeric(10,2),
    vremya_pokupki timestamp without time zone DEFAULT now(),
    status character varying(20),
    id_seansa integer,
    id_mesta integer
);


ALTER TABLE public.bilet OWNER TO postgres;

--
-- Name: bilet_id_bileta_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bilet_id_bileta_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bilet_id_bileta_seq OWNER TO postgres;

--
-- Name: bilet_id_bileta_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bilet_id_bileta_seq OWNED BY public.bilet.id_bileta;


--
-- Name: film; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.film (
    id_filma integer NOT NULL,
    nazvanie character varying(100) NOT NULL,
    zhanr character varying(50),
    vozrastnoy_reiting character varying(5),
    prodolzhitelnost integer
);


ALTER TABLE public.film OWNER TO postgres;

--
-- Name: film_id_filma_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.film_id_filma_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.film_id_filma_seq OWNER TO postgres;

--
-- Name: film_id_filma_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.film_id_filma_seq OWNED BY public.film.id_filma;


--
-- Name: kinozal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kinozal (
    id_zala integer NOT NULL,
    nazvanie_zala character varying(50),
    vmestimost integer
);


ALTER TABLE public.kinozal OWNER TO postgres;

--
-- Name: kinozal_id_zala_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.kinozal_id_zala_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.kinozal_id_zala_seq OWNER TO postgres;

--
-- Name: kinozal_id_zala_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.kinozal_id_zala_seq OWNED BY public.kinozal.id_zala;


--
-- Name: mesto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mesto (
    id_mesta integer NOT NULL,
    ryad integer,
    nomer_mesta integer,
    kategoria character varying(20),
    id_zala integer
);


ALTER TABLE public.mesto OWNER TO postgres;

--
-- Name: mesto_id_mesta_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mesto_id_mesta_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mesto_id_mesta_seq OWNER TO postgres;

--
-- Name: mesto_id_mesta_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mesto_id_mesta_seq OWNED BY public.mesto.id_mesta;


--
-- Name: seans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.seans (
    id_seansa integer NOT NULL,
    data_vremya timestamp without time zone,
    tip_pokaza character varying(20),
    id_filma integer,
    id_zala integer
);


ALTER TABLE public.seans OWNER TO postgres;

--
-- Name: seans_id_seansa_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.seans_id_seansa_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seans_id_seansa_seq OWNER TO postgres;

--
-- Name: seans_id_seansa_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.seans_id_seansa_seq OWNED BY public.seans.id_seansa;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id_users integer NOT NULL,
    login character varying(50),
    parol_hash character varying(255),
    rol character varying(20)
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_users_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_users_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_users_seq OWNER TO postgres;

--
-- Name: users_id_users_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_users_seq OWNED BY public.users.id_users;


--
-- Name: Билет; Type: TABLE; Schema: public; Owner: admin_user
--

CREATE TABLE public."Билет" (
    "id_билета" integer NOT NULL,
    "Цена" numeric(10,2) NOT NULL,
    "Время_покупки" timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "Статус" character varying(20) DEFAULT 'активен'::character varying NOT NULL,
    "id_сеанса" integer NOT NULL,
    "id_места" integer NOT NULL,
    "id_клиента" integer NOT NULL,
    CONSTRAINT "Билет_Цена_check" CHECK (("Цена" >= (0)::numeric))
);


ALTER TABLE public."Билет" OWNER TO admin_user;

--
-- Name: Билет_id_билета_seq; Type: SEQUENCE; Schema: public; Owner: admin_user
--

CREATE SEQUENCE public."Билет_id_билета_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Билет_id_билета_seq" OWNER TO admin_user;

--
-- Name: Билет_id_билета_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin_user
--

ALTER SEQUENCE public."Билет_id_билета_seq" OWNED BY public."Билет"."id_билета";


--
-- Name: Журнал_логов; Type: TABLE; Schema: public; Owner: admin_user
--

CREATE TABLE public."Журнал_логов" (
    "id_лога" integer NOT NULL,
    "Пользователь" character varying(50) NOT NULL,
    "Действие" character varying(10) NOT NULL,
    "Таблица" character varying(50) NOT NULL,
    "Дата_время" timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "Старые_данные" text,
    "Новые_данные" text
);


ALTER TABLE public."Журнал_логов" OWNER TO admin_user;

--
-- Name: Журнал_логов_id_лога_seq; Type: SEQUENCE; Schema: public; Owner: admin_user
--

CREATE SEQUENCE public."Журнал_логов_id_лога_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Журнал_логов_id_лога_seq" OWNER TO admin_user;

--
-- Name: Журнал_логов_id_лога_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin_user
--

ALTER SEQUENCE public."Журнал_логов_id_лога_seq" OWNED BY public."Журнал_логов"."id_лога";


--
-- Name: Кинозал; Type: TABLE; Schema: public; Owner: admin_user
--

CREATE TABLE public."Кинозал" (
    "id_зала" integer NOT NULL,
    "Название_зала" character varying(50) NOT NULL,
    "Вместимость" integer NOT NULL,
    CONSTRAINT "Кинозал_Вместимость_check" CHECK (("Вместимость" > 0))
);


ALTER TABLE public."Кинозал" OWNER TO admin_user;

--
-- Name: Кинозал_id_зала_seq; Type: SEQUENCE; Schema: public; Owner: admin_user
--

CREATE SEQUENCE public."Кинозал_id_зала_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Кинозал_id_зала_seq" OWNER TO admin_user;

--
-- Name: Кинозал_id_зала_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin_user
--

ALTER SEQUENCE public."Кинозал_id_зала_seq" OWNED BY public."Кинозал"."id_зала";


--
-- Name: Клиент; Type: TABLE; Schema: public; Owner: admin_user
--

CREATE TABLE public."Клиент" (
    "id_клиента" integer NOT NULL,
    "Фамилия" character varying(50) NOT NULL,
    "Имя" character varying(50) NOT NULL,
    "Телефон" character varying(20) NOT NULL,
    email character varying(100)
);


ALTER TABLE public."Клиент" OWNER TO admin_user;

--
-- Name: Клиент_id_клиента_seq; Type: SEQUENCE; Schema: public; Owner: admin_user
--

CREATE SEQUENCE public."Клиент_id_клиента_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Клиент_id_клиента_seq" OWNER TO admin_user;

--
-- Name: Клиент_id_клиента_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin_user
--

ALTER SEQUENCE public."Клиент_id_клиента_seq" OWNED BY public."Клиент"."id_клиента";


--
-- Name: Место; Type: TABLE; Schema: public; Owner: admin_user
--

CREATE TABLE public."Место" (
    "id_места" integer NOT NULL,
    "Ряд" integer NOT NULL,
    "Номер_места" integer NOT NULL,
    "Категория" character varying(20) DEFAULT 'Стандарт'::character varying NOT NULL,
    "id_зала" integer NOT NULL,
    CONSTRAINT "Место_Номер_места_check" CHECK (("Номер_места" > 0)),
    CONSTRAINT "Место_Ряд_check" CHECK (("Ряд" > 0))
);


ALTER TABLE public."Место" OWNER TO admin_user;

--
-- Name: Место_id_места_seq; Type: SEQUENCE; Schema: public; Owner: admin_user
--

CREATE SEQUENCE public."Место_id_места_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Место_id_места_seq" OWNER TO admin_user;

--
-- Name: Место_id_места_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin_user
--

ALTER SEQUENCE public."Место_id_места_seq" OWNED BY public."Место"."id_места";


--
-- Name: Пользователь; Type: TABLE; Schema: public; Owner: admin_user
--

CREATE TABLE public."Пользователь" (
    "id_пользователя" integer NOT NULL,
    "Логин" character varying(50) NOT NULL,
    "Пароль_хэш" character varying(255) NOT NULL,
    "Роль" character varying(20) NOT NULL,
    "id_клиента" integer,
    CONSTRAINT "Пользователь_Роль_check" CHECK ((("Роль")::text = ANY ((ARRAY['admin'::character varying, 'kasir'::character varying, 'guest'::character varying])::text[])))
);


ALTER TABLE public."Пользователь" OWNER TO admin_user;

--
-- Name: Пользователь_id_пользователя_seq; Type: SEQUENCE; Schema: public; Owner: admin_user
--

CREATE SEQUENCE public."Пользователь_id_пользователя_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Пользователь_id_пользователя_seq" OWNER TO admin_user;

--
-- Name: Пользователь_id_пользователя_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin_user
--

ALTER SEQUENCE public."Пользователь_id_пользователя_seq" OWNED BY public."Пользователь"."id_пользователя";


--
-- Name: Сеанс; Type: TABLE; Schema: public; Owner: admin_user
--

CREATE TABLE public."Сеанс" (
    "id_сеанса" integer NOT NULL,
    "Дата_время" timestamp without time zone NOT NULL,
    "Тип_показа" character varying(20) DEFAULT '2D'::character varying NOT NULL,
    "id_фильма" integer NOT NULL,
    "id_зала" integer NOT NULL
);


ALTER TABLE public."Сеанс" OWNER TO admin_user;

--
-- Name: Сеанс_id_сеанса_seq; Type: SEQUENCE; Schema: public; Owner: admin_user
--

CREATE SEQUENCE public."Сеанс_id_сеанса_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Сеанс_id_сеанса_seq" OWNER TO admin_user;

--
-- Name: Сеанс_id_сеанса_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin_user
--

ALTER SEQUENCE public."Сеанс_id_сеанса_seq" OWNED BY public."Сеанс"."id_сеанса";


--
-- Name: Фильм; Type: TABLE; Schema: public; Owner: admin_user
--

CREATE TABLE public."Фильм" (
    "id_фильма" integer NOT NULL,
    "Название" character varying(100) NOT NULL,
    "Жанр" character varying(50) NOT NULL,
    "Возрастной_рейтинг" character varying(5) DEFAULT '0+'::character varying NOT NULL,
    "Продолжительность" integer NOT NULL,
    CONSTRAINT "Фильм_Продолжительность_check" CHECK (("Продолжительность" > 0))
);


ALTER TABLE public."Фильм" OWNER TO admin_user;

--
-- Name: Фильм_id_фильма_seq; Type: SEQUENCE; Schema: public; Owner: admin_user
--

CREATE SEQUENCE public."Фильм_id_фильма_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Фильм_id_фильма_seq" OWNER TO admin_user;

--
-- Name: Фильм_id_фильма_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin_user
--

ALTER SEQUENCE public."Фильм_id_фильма_seq" OWNED BY public."Фильм"."id_фильма";


--
-- Name: bilet id_bileta; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bilet ALTER COLUMN id_bileta SET DEFAULT nextval('public.bilet_id_bileta_seq'::regclass);


--
-- Name: film id_filma; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.film ALTER COLUMN id_filma SET DEFAULT nextval('public.film_id_filma_seq'::regclass);


--
-- Name: kinozal id_zala; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kinozal ALTER COLUMN id_zala SET DEFAULT nextval('public.kinozal_id_zala_seq'::regclass);


--
-- Name: mesto id_mesta; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mesto ALTER COLUMN id_mesta SET DEFAULT nextval('public.mesto_id_mesta_seq'::regclass);


--
-- Name: seans id_seansa; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.seans ALTER COLUMN id_seansa SET DEFAULT nextval('public.seans_id_seansa_seq'::regclass);


--
-- Name: users id_users; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id_users SET DEFAULT nextval('public.users_id_users_seq'::regclass);


--
-- Name: Билет id_билета; Type: DEFAULT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY public."Билет" ALTER COLUMN "id_билета" SET DEFAULT nextval('public."Билет_id_билета_seq"'::regclass);


--
-- Name: Журнал_логов id_лога; Type: DEFAULT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY public."Журнал_логов" ALTER COLUMN "id_лога" SET DEFAULT nextval('public."Журнал_логов_id_лога_seq"'::regclass);


--
-- Name: Кинозал id_зала; Type: DEFAULT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY public."Кинозал" ALTER COLUMN "id_зала" SET DEFAULT nextval('public."Кинозал_id_зала_seq"'::regclass);


--
-- Name: Клиент id_клиента; Type: DEFAULT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY public."Клиент" ALTER COLUMN "id_клиента" SET DEFAULT nextval('public."Клиент_id_клиента_seq"'::regclass);


--
-- Name: Место id_места; Type: DEFAULT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY public."Место" ALTER COLUMN "id_места" SET DEFAULT nextval('public."Место_id_места_seq"'::regclass);


--
-- Name: Пользователь id_пользователя; Type: DEFAULT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY public."Пользователь" ALTER COLUMN "id_пользователя" SET DEFAULT nextval('public."Пользователь_id_пользователя_seq"'::regclass);


--
-- Name: Сеанс id_сеанса; Type: DEFAULT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY public."Сеанс" ALTER COLUMN "id_сеанса" SET DEFAULT nextval('public."Сеанс_id_сеанса_seq"'::regclass);


--
-- Name: Фильм id_фильма; Type: DEFAULT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY public."Фильм" ALTER COLUMN "id_фильма" SET DEFAULT nextval('public."Фильм_id_фильма_seq"'::regclass);


--
-- Data for Name: bilet; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bilet (id_bileta, cena, vremya_pokupki, status, id_seansa, id_mesta) FROM stdin;
\.


--
-- Data for Name: film; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.film (id_filma, nazvanie, zhanr, vozrastnoy_reiting, prodolzhitelnost) FROM stdin;
1	Avatar	fantasy	\N	162
2	Dune	fantasy	\N	155
\.


--
-- Data for Name: kinozal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kinozal (id_zala, nazvanie_zala, vmestimost) FROM stdin;
1	Red Hall	50
2	Blue Hall	40
\.


--
-- Data for Name: mesto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mesto (id_mesta, ryad, nomer_mesta, kategoria, id_zala) FROM stdin;
\.


--
-- Data for Name: seans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.seans (id_seansa, data_vremya, tip_pokaza, id_filma, id_zala) FROM stdin;
1	2026-05-18 12:19:31.677543	2D	1	1
2	2026-05-18 15:19:31.677543	3D	2	2
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id_users, login, parol_hash, rol) FROM stdin;
1	admin	admin123	admin
2	kasir	kasir123	kasir
3	guest	guest	guest
\.


--
-- Data for Name: Билет; Type: TABLE DATA; Schema: public; Owner: admin_user
--

COPY public."Билет" ("id_билета", "Цена", "Время_покупки", "Статус", "id_сеанса", "id_места", "id_клиента") FROM stdin;
1	300.00	2026-05-17 23:37:31.761143	активен	1	1	1
2	300.00	2026-05-17 23:37:31.761143	активен	1	2	2
3	700.00	2026-05-17 23:37:31.761143	активен	2	1	1
\.


--
-- Data for Name: Журнал_логов; Type: TABLE DATA; Schema: public; Owner: admin_user
--

COPY public."Журнал_логов" ("id_лога", "Пользователь", "Действие", "Таблица", "Дата_время", "Старые_данные", "Новые_данные") FROM stdin;
\.


--
-- Data for Name: Кинозал; Type: TABLE DATA; Schema: public; Owner: admin_user
--

COPY public."Кинозал" ("id_зала", "Название_зала", "Вместимость") FROM stdin;
1	Красный зал	50
2	Синий зал	40
\.


--
-- Data for Name: Клиент; Type: TABLE DATA; Schema: public; Owner: admin_user
--

COPY public."Клиент" ("id_клиента", "Фамилия", "Имя", "Телефон", email) FROM stdin;
1	Иванов	Иван	+79101234567	\N
2	Петрова	Мария	+79107654321	\N
\.


--
-- Data for Name: Место; Type: TABLE DATA; Schema: public; Owner: admin_user
--

COPY public."Место" ("id_места", "Ряд", "Номер_места", "Категория", "id_зала") FROM stdin;
1	1	1	VIP	1
2	1	2	VIP	1
3	1	3	VIP	1
4	1	4	VIP	1
5	1	5	VIP	1
6	1	6	VIP	1
7	1	7	VIP	1
8	1	8	VIP	1
9	1	9	VIP	1
10	1	10	VIP	1
11	2	1	VIP	1
12	2	2	VIP	1
13	2	3	VIP	1
14	2	4	VIP	1
15	2	5	VIP	1
16	2	6	VIP	1
17	2	7	VIP	1
18	2	8	VIP	1
19	2	9	VIP	1
20	2	10	VIP	1
21	3	1	Комфорт	1
22	3	2	Комфорт	1
23	3	3	Комфорт	1
24	3	4	Комфорт	1
25	3	5	Комфорт	1
26	3	6	Комфорт	1
27	3	7	Комфорт	1
28	3	8	Комфорт	1
29	3	9	Комфорт	1
30	3	10	Комфорт	1
31	4	1	Стандарт	1
32	4	2	Стандарт	1
33	4	3	Стандарт	1
34	4	4	Стандарт	1
35	4	5	Стандарт	1
36	4	6	Стандарт	1
37	4	7	Стандарт	1
38	4	8	Стандарт	1
39	4	9	Стандарт	1
40	4	10	Стандарт	1
41	5	1	Стандарт	1
42	5	2	Стандарт	1
43	5	3	Стандарт	1
44	5	4	Стандарт	1
45	5	5	Стандарт	1
46	5	6	Стандарт	1
47	5	7	Стандарт	1
48	5	8	Стандарт	1
49	5	9	Стандарт	1
50	5	10	Стандарт	1
\.


--
-- Data for Name: Пользователь; Type: TABLE DATA; Schema: public; Owner: admin_user
--

COPY public."Пользователь" ("id_пользователя", "Логин", "Пароль_хэш", "Роль", "id_клиента") FROM stdin;
1	admin	admin123	admin	\N
2	kasir	kasir123	kasir	\N
3	guest	guest	guest	\N
\.


--
-- Data for Name: Сеанс; Type: TABLE DATA; Schema: public; Owner: admin_user
--

COPY public."Сеанс" ("id_сеанса", "Дата_время", "Тип_показа", "id_фильма", "id_зала") FROM stdin;
1	2026-05-18 01:37:11.837844	2D	1	1
2	2026-05-18 04:37:11.837844	3D	2	2
3	2026-05-19 02:37:11.837844	2D	3	1
\.


--
-- Data for Name: Фильм; Type: TABLE DATA; Schema: public; Owner: admin_user
--

COPY public."Фильм" ("id_фильма", "Название", "Жанр", "Возрастной_рейтинг", "Продолжительность") FROM stdin;
1	Аватар: Путь воды	фантастика	12+	192
2	Оппенгеймер	драма	18+	180
3	Барби	комедия	12+	114
4	Дюна: Часть вторая	фантастика	12+	166
\.


--
-- Name: bilet_id_bileta_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bilet_id_bileta_seq', 1, false);


--
-- Name: film_id_filma_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.film_id_filma_seq', 2, true);


--
-- Name: kinozal_id_zala_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.kinozal_id_zala_seq', 2, true);


--
-- Name: mesto_id_mesta_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mesto_id_mesta_seq', 1, false);


--
-- Name: seans_id_seansa_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.seans_id_seansa_seq', 2, true);


--
-- Name: users_id_users_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_users_seq', 3, true);


--
-- Name: Билет_id_билета_seq; Type: SEQUENCE SET; Schema: public; Owner: admin_user
--

SELECT pg_catalog.setval('public."Билет_id_билета_seq"', 3, true);


--
-- Name: Журнал_логов_id_лога_seq; Type: SEQUENCE SET; Schema: public; Owner: admin_user
--

SELECT pg_catalog.setval('public."Журнал_логов_id_лога_seq"', 1, false);


--
-- Name: Кинозал_id_зала_seq; Type: SEQUENCE SET; Schema: public; Owner: admin_user
--

SELECT pg_catalog.setval('public."Кинозал_id_зала_seq"', 2, true);


--
-- Name: Клиент_id_клиента_seq; Type: SEQUENCE SET; Schema: public; Owner: admin_user
--

SELECT pg_catalog.setval('public."Клиент_id_клиента_seq"', 2, true);


--
-- Name: Место_id_места_seq; Type: SEQUENCE SET; Schema: public; Owner: admin_user
--

SELECT pg_catalog.setval('public."Место_id_места_seq"', 50, true);


--
-- Name: Пользователь_id_пользователя_seq; Type: SEQUENCE SET; Schema: public; Owner: admin_user
--

SELECT pg_catalog.setval('public."Пользователь_id_пользователя_seq"', 3, true);


--
-- Name: Сеанс_id_сеанса_seq; Type: SEQUENCE SET; Schema: public; Owner: admin_user
--

SELECT pg_catalog.setval('public."Сеанс_id_сеанса_seq"', 3, true);


--
-- Name: Фильм_id_фильма_seq; Type: SEQUENCE SET; Schema: public; Owner: admin_user
--

SELECT pg_catalog.setval('public."Фильм_id_фильма_seq"', 4, true);


--
-- Name: bilet bilet_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bilet
    ADD CONSTRAINT bilet_pkey PRIMARY KEY (id_bileta);


--
-- Name: film film_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.film
    ADD CONSTRAINT film_pkey PRIMARY KEY (id_filma);


--
-- Name: kinozal kinozal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kinozal
    ADD CONSTRAINT kinozal_pkey PRIMARY KEY (id_zala);


--
-- Name: mesto mesto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mesto
    ADD CONSTRAINT mesto_pkey PRIMARY KEY (id_mesta);


--
-- Name: seans seans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.seans
    ADD CONSTRAINT seans_pkey PRIMARY KEY (id_seansa);


--
-- Name: users users_login_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_login_key UNIQUE (login);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id_users);


--
-- Name: Билет Билет_pkey; Type: CONSTRAINT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY public."Билет"
    ADD CONSTRAINT "Билет_pkey" PRIMARY KEY ("id_билета");


--
-- Name: Журнал_логов Журнал_логов_pkey; Type: CONSTRAINT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY public."Журнал_логов"
    ADD CONSTRAINT "Журнал_логов_pkey" PRIMARY KEY ("id_лога");


--
-- Name: Кинозал Кинозал_pkey; Type: CONSTRAINT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY public."Кинозал"
    ADD CONSTRAINT "Кинозал_pkey" PRIMARY KEY ("id_зала");


--
-- Name: Клиент Клиент_pkey; Type: CONSTRAINT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY public."Клиент"
    ADD CONSTRAINT "Клиент_pkey" PRIMARY KEY ("id_клиента");


--
-- Name: Клиент Клиент_Телефон_key; Type: CONSTRAINT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY public."Клиент"
    ADD CONSTRAINT "Клиент_Телефон_key" UNIQUE ("Телефон");


--
-- Name: Место Место_pkey; Type: CONSTRAINT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY public."Место"
    ADD CONSTRAINT "Место_pkey" PRIMARY KEY ("id_места");


--
-- Name: Пользователь Пользователь_pkey; Type: CONSTRAINT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY public."Пользователь"
    ADD CONSTRAINT "Пользователь_pkey" PRIMARY KEY ("id_пользователя");


--
-- Name: Пользователь Пользователь_Логин_key; Type: CONSTRAINT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY public."Пользователь"
    ADD CONSTRAINT "Пользователь_Логин_key" UNIQUE ("Логин");


--
-- Name: Сеанс Сеанс_pkey; Type: CONSTRAINT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY public."Сеанс"
    ADD CONSTRAINT "Сеанс_pkey" PRIMARY KEY ("id_сеанса");


--
-- Name: Фильм Фильм_pkey; Type: CONSTRAINT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY public."Фильм"
    ADD CONSTRAINT "Фильм_pkey" PRIMARY KEY ("id_фильма");


--
-- Name: idx_bilet_status; Type: INDEX; Schema: public; Owner: admin_user
--

CREATE INDEX idx_bilet_status ON public."Билет" USING btree ("Статус");


--
-- Name: idx_log_datetime; Type: INDEX; Schema: public; Owner: admin_user
--

CREATE INDEX idx_log_datetime ON public."Журнал_логов" USING btree ("Дата_время");


--
-- Name: idx_seans_datetime; Type: INDEX; Schema: public; Owner: admin_user
--

CREATE INDEX idx_seans_datetime ON public."Сеанс" USING btree ("Дата_время");


--
-- Name: Билет билет_log_delete; Type: TRIGGER; Schema: public; Owner: admin_user
--

CREATE TRIGGER "билет_log_delete" AFTER DELETE ON public."Билет" FOR EACH ROW EXECUTE FUNCTION public.log_changes();


--
-- Name: Билет билет_log_insert; Type: TRIGGER; Schema: public; Owner: admin_user
--

CREATE TRIGGER "билет_log_insert" AFTER INSERT ON public."Билет" FOR EACH ROW EXECUTE FUNCTION public.log_changes();


--
-- Name: Билет билет_log_update; Type: TRIGGER; Schema: public; Owner: admin_user
--

CREATE TRIGGER "билет_log_update" AFTER UPDATE ON public."Билет" FOR EACH ROW EXECUTE FUNCTION public.log_changes();


--
-- Name: Сеанс сеанс_log_delete; Type: TRIGGER; Schema: public; Owner: admin_user
--

CREATE TRIGGER "сеанс_log_delete" AFTER DELETE ON public."Сеанс" FOR EACH ROW EXECUTE FUNCTION public.log_changes();


--
-- Name: Сеанс сеанс_log_insert; Type: TRIGGER; Schema: public; Owner: admin_user
--

CREATE TRIGGER "сеанс_log_insert" AFTER INSERT ON public."Сеанс" FOR EACH ROW EXECUTE FUNCTION public.log_changes();


--
-- Name: Сеанс сеанс_log_update; Type: TRIGGER; Schema: public; Owner: admin_user
--

CREATE TRIGGER "сеанс_log_update" AFTER UPDATE ON public."Сеанс" FOR EACH ROW EXECUTE FUNCTION public.log_changes();


--
-- Name: bilet bilet_id_mesta_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bilet
    ADD CONSTRAINT bilet_id_mesta_fkey FOREIGN KEY (id_mesta) REFERENCES public.mesto(id_mesta);


--
-- Name: bilet bilet_id_seansa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bilet
    ADD CONSTRAINT bilet_id_seansa_fkey FOREIGN KEY (id_seansa) REFERENCES public.seans(id_seansa);


--
-- Name: mesto mesto_id_zala_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mesto
    ADD CONSTRAINT mesto_id_zala_fkey FOREIGN KEY (id_zala) REFERENCES public.kinozal(id_zala);


--
-- Name: seans seans_id_filma_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.seans
    ADD CONSTRAINT seans_id_filma_fkey FOREIGN KEY (id_filma) REFERENCES public.film(id_filma);


--
-- Name: seans seans_id_zala_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.seans
    ADD CONSTRAINT seans_id_zala_fkey FOREIGN KEY (id_zala) REFERENCES public.kinozal(id_zala);


--
-- Name: Билет Билет_id_клиента_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY public."Билет"
    ADD CONSTRAINT "Билет_id_клиента_fkey" FOREIGN KEY ("id_клиента") REFERENCES public."Клиент"("id_клиента");


--
-- Name: Билет Билет_id_места_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY public."Билет"
    ADD CONSTRAINT "Билет_id_места_fkey" FOREIGN KEY ("id_места") REFERENCES public."Место"("id_места");


--
-- Name: Билет Билет_id_сеанса_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY public."Билет"
    ADD CONSTRAINT "Билет_id_сеанса_fkey" FOREIGN KEY ("id_сеанса") REFERENCES public."Сеанс"("id_сеанса");


--
-- Name: Место Место_id_зала_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY public."Место"
    ADD CONSTRAINT "Место_id_зала_fkey" FOREIGN KEY ("id_зала") REFERENCES public."Кинозал"("id_зала") ON DELETE CASCADE;


--
-- Name: Пользователь Пользователь_id_клиента_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY public."Пользователь"
    ADD CONSTRAINT "Пользователь_id_клиента_fkey" FOREIGN KEY ("id_клиента") REFERENCES public."Клиент"("id_клиента");


--
-- Name: Сеанс Сеанс_id_зала_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY public."Сеанс"
    ADD CONSTRAINT "Сеанс_id_зала_fkey" FOREIGN KEY ("id_зала") REFERENCES public."Кинозал"("id_зала") ON DELETE CASCADE;


--
-- Name: Сеанс Сеанс_id_фильма_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY public."Сеанс"
    ADD CONSTRAINT "Сеанс_id_фильма_fkey" FOREIGN KEY ("id_фильма") REFERENCES public."Фильм"("id_фильма") ON DELETE CASCADE;


--
-- Name: TABLE "Билет"; Type: ACL; Schema: public; Owner: admin_user
--

GRANT SELECT,INSERT,UPDATE ON TABLE public."Билет" TO kasir_user;


--
-- Name: TABLE "Кинозал"; Type: ACL; Schema: public; Owner: admin_user
--

GRANT SELECT ON TABLE public."Кинозал" TO kasir_user;
GRANT SELECT ON TABLE public."Кинозал" TO guest_user;


--
-- Name: TABLE "Клиент"; Type: ACL; Schema: public; Owner: admin_user
--

GRANT SELECT,INSERT ON TABLE public."Клиент" TO kasir_user;


--
-- Name: TABLE "Место"; Type: ACL; Schema: public; Owner: admin_user
--

GRANT SELECT ON TABLE public."Место" TO kasir_user;
GRANT SELECT ON TABLE public."Место" TO guest_user;


--
-- Name: TABLE "Сеанс"; Type: ACL; Schema: public; Owner: admin_user
--

GRANT SELECT ON TABLE public."Сеанс" TO kasir_user;
GRANT SELECT ON TABLE public."Сеанс" TO guest_user;


--
-- Name: TABLE "Фильм"; Type: ACL; Schema: public; Owner: admin_user
--

GRANT SELECT ON TABLE public."Фильм" TO kasir_user;
GRANT SELECT ON TABLE public."Фильм" TO guest_user;


--
-- PostgreSQL database dump complete
--

\unrestrict DkWE9c7l4BY0FEev2jhph4kWGDGwiGwOB34G8s5Bacmnaqg62ecupzd61sNqbNa

