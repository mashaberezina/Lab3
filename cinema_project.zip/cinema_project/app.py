from flask import Flask, request, redirect, url_for, session, render_template
import pg8000

# СОЗДАНИЕ ПРИЛОЖЕНИЯ FLASK

app = Flask(__name__)
# Секретный ключ для шифрования сессий (нужен для сохранения состояния входа)
app.secret_key = 'cinema_secret_key_2026'


# ФУНКЦИЯ ПОДКЛЮЧЕНИЯ К БАЗЕ ДАННЫХ

def get_db_connection(login, password):
    """
    Подключение к базе данных PostgreSQL под конкретным пользователем.
    
    Параметры:
        login (str): логин пользователя (admin/kasir/guest)
        password (str): пароль пользователя
    
    Возвращает:
        connection: объект подключения к БД или None при ошибке
    
    Важно: Подключение происходит под тем пользователем, который ввёл логин и пароль,
           а не под суперпользователем postgres. Это обеспечивает разграничение доступа.
    """
    try:
        # Если пароль не передан (например, при вызове из сессии), используем стандартные пароли
        if not password:
            if login == 'admin':
                password = 'admin123'
            elif login == 'kasir':
                password = 'kasir123'
            elif login == 'guest':
                password = 'guest'
        
        # Подключение к PostgreSQL через драйвер pg8000
        conn = pg8000.connect(
            host='127.0.0.1',        # локальный хост (этот же компьютер)
            port=5432,               # стандартный порт PostgreSQL
            user=login,              # имя пользователя (НЕ postgres!)
            password=password,       # пароль пользователя
            database='cinema_october' # имя базы данных
        )
        return conn
    except Exception as e:
        print(f"Ошибка подключения для пользователя {login}: {e}")
        return None


# ДЕКОРАТОРЫ ДЛЯ ПРОВЕРКИ ПРАВ ДОСТУПА

def login_required(f):
    """
    Декоратор для проверки авторизации пользователя.
    
    Если пользователь не авторизован (нет сессии), перенаправляет на страницу входа.
    
    Использование:
        @login_required
        def some_function():
            ...
    """
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        # Проверяем, есть ли пользователь в сессии
        if 'user' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated


def role_required(required_role):
    """
    Декоратор для проверки роли пользователя.
    
    Параметры:
        required_role (str): требуемая роль ('admin', 'kasir', 'guest')
    
    Использование:
        @role_required('admin')
        def admin_function():
            ...
    """
    from functools import wraps
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            # Проверяем, имеет ли пользователь нужную роль (или он admin)
            if session.get('role') != required_role and session.get('role') != 'admin':
                return "Доступ запрещён", 403
            return f(*args, **kwargs)
        return decorated
    return decorator


# ГЛАВНАЯ СТРАНИЦА

@app.route('/')
def index():
    """
    Главная страница приложения.
    
    Доступна всем пользователям (включая неавторизованных).
    Показывает кнопки входа в систему и просмотра расписания.
    
    Возвращает:
        HTML-страницу index.html
    """
    return render_template('index.html')

# АВТОРИЗАЦИЯ

@app.route('/login', methods=['GET', 'POST'])
def login():
    """
    Страница входа в систему.
    
    GET: Отображает форму входа
    POST: Проверяет логин и пароль, создаёт сессию и перенаправляет на панель пользователя
    
    Возвращает:
        GET: HTML-страницу login.html
        POST: перенаправление на admin_panel/kasir_panel/guest_panel или ошибку
    """
    if request.method == 'POST':
        # Получаем данные из формы
        login = request.form['login']
        password = request.form['password']
        
        # Подключаемся к БД под введёнными логином и паролем
        conn = get_db_connection(login, password)
        if conn:
            cursor = conn.cursor()
            # Проверяем существование пользователя
            cursor.execute("SELECT rol FROM users WHERE login=%s AND parol_hash=%s", (login, password))
            row = cursor.fetchone()
            cursor.close()
            conn.close()
            
            if row:
                # Сохраняем данные пользователя в сессии
                session['user'] = login
                session['role'] = row[0]
                
                # Перенаправляем на соответствующую панель
                if row[0] == 'admin':
                    return redirect('/admin_panel')
                elif row[0] == 'kasir':
                    return redirect('/kasir_panel')
                else:
                    return redirect('/guest_panel')
        
        # Если логин или пароль неверны
        return render_template('login.html', error='Неверный логин или пароль')
    
    return render_template('login.html')

# ВЫХОД ИЗ СИСТЕМЫ

@app.route('/logout')
def logout():
    """
    Выход из системы.
    
    Очищает сессию пользователя и перенаправляет на главную страницу.
    """
    session.clear()
    return redirect('/')

# ПРОСМОТР РАСПИСАНИЯ (ДОСТУПНО БЕЗ АВТОРИЗАЦИИ)

@app.route('/schedule')
def schedule():
    """
    Просмотр расписания сеансов.
    
    Доступно без авторизации (используется пользователь guest).
    Показывает все будущие сеансы с информацией о фильмах и залах.
    
    Возвращает:
        HTML-страницу schedule.html с списком сеансов
    """
    # Подключаемся как guest (пользователь с минимальными правами)
    conn = get_db_connection('guest', 'guest')
    if not conn:
        return "Ошибка подключения к базе данных"
    
    cursor = conn.cursor()
    # Запрос: выбираем будущие сеансы, присоединяем названия фильмов и залов
    # to_char - преобразует дату в читаемый формат
    cursor.execute("""
        SELECT s.id_seansa, f.nazvanie, to_char(s.data_vremya,'DD.MM.YYYY HH24:MI'), 
               z.nazvanie_zala, s.tip_pokaza
        FROM seans s 
        JOIN film f ON s.id_filma=f.id_filma 
        JOIN kinozal z ON s.id_zala=z.id_zala
        WHERE s.data_vremya >= NOW() 
        ORDER BY s.data_vremya
    """)
    rows = cursor.fetchall()
    cursor.close()
    conn.close()
    
    return render_template('schedule.html', seansy=rows)

# ПРОСМОТР СПИСКА ФИЛЬМОВ (ТОЛЬКО ADMIN И KASIR)


@app.route('/films')
@login_required
def films():
    """
    Просмотр списка всех фильмов в прокате.
    
    Доступно только администратору и кассиру.
    Гость не имеет доступа к этому пункту меню.
    
    Возвращает:
        HTML-страницу films.html с списком фильмов
    """
    # Подключаемся под текущим пользователем
    conn = get_db_connection(session['user'], '')
    if not conn:
        return "Ошибка подключения к базе данных"
    
    cursor = conn.cursor()
    cursor.execute("SELECT id_filma, nazvanie, zhanr, prodolzhitelnost FROM film ORDER BY id_filma")
    rows = cursor.fetchall()
    cursor.close()
    conn.close()
    
    return render_template('films.html', films=rows)

# ПАНЕЛЬ АДМИНИСТРАТОРА

@app.route('/admin_panel')
@login_required
def admin_panel():
    """
    Панель администратора.
    
    Доступна только пользователям с ролью 'admin'.
    Содержит 10 пунктов меню для управления системой.
    
    Возвращает:
        HTML-страницу admin_panel.html
    """
    if session.get('role') != 'admin':
        return "Доступ запрещён", 403
    
    return render_template('admin_panel.html', user=session['user'])

# ПАНЕЛЬ КАССИРА

@app.route('/kasir_panel')
@login_required
def kasir_panel():
    """
    Панель кассира.
    
    Доступна пользователям с ролью 'admin' или 'kasir'.
    Содержит 4 пункта меню (расписание, фильмы, продажа/возврат билетов).
    
    Возвращает:
        HTML-страницу kasir_panel.html
    """
    if session.get('role') not in ['admin', 'kasir']:
        return "Доступ запрещён", 403
    
    return render_template('kasir_panel.html', user=session['user'])

# ПАНЕЛЬ ГОСТЯ


@app.route('/guest_panel')
@login_required
def guest_panel():
    """
    Панель гостя.
    
    Доступна пользователям с ролью 'guest'.
    Содержит 3 пункта меню (расписание, купить билет, вернуть билет).
    
    Возвращает:
        HTML-страницу guest_panel.html
    """
    return render_template('guest_panel.html', user=session['user'])


# ПРОДАЖА БИЛЕТА


@app.route('/buy_ticket', methods=['GET', 'POST'])
@login_required
def buy_ticket():
    """
    Продажа билета.
    
    Доступно всем авторизованным пользователям (admin, kasir, guest).
    
    GET: Показывает форму выбора сеанса
    POST: Обрабатывает продажу билета
    
    Алгоритм POST:
        1. Поиск клиента по телефону (или создание нового)
        2. Проверка, что место существует и свободно
        3. Создание билета со статусом 'active'
        4. Сохранение в БД и возврат на панель пользователя
    
    Возвращает:
        GET: HTML-страницу buy_ticket.html с списком сеансов
        POST: перенаправление на панель пользователя или сообщение об ошибке
    """
    if request.method == 'POST':
        # Получаем данные из формы
        seans_id = request.form['seans_id']
        familiya = request.form['familiya']
        imya = request.form['imya']
        telefon = request.form['telefon']
        email = request.form.get('email') or None
        ryad = request.form['ryad']
        mesto_nomer = request.form['mesto_nomer']
        
        conn = get_db_connection(session['user'], '')
        if not conn:
            return "Ошибка подключения к базе данных"
        
        cursor = conn.cursor()
        try:
            # ========== ШАГ 1: ПОИСК ИЛИ СОЗДАНИЕ КЛИЕНТА ==========
            # Важно: сначала ищем клиента по телефону, чтобы избежать дублирования
            # из-за ограничения UNIQUE на поле telefon
            cursor.execute("SELECT id_clienta FROM client WHERE telefon=%s", (telefon,))
            client = cursor.fetchone()
            if client:
                client_id = client[0]
            else:
                # Создаём нового клиента
                cursor.execute("""
                    INSERT INTO client (familiya, imya, telefon, email) 
                    VALUES (%s, %s, %s, %s) RETURNING id_clienta
                """, (familiya, imya, telefon, email))
                client_id = cursor.fetchone()[0]
            
            # ========== ШАГ 2: ПОИСК МЕСТА ==========
            cursor.execute("""
                SELECT m.id_mesta FROM mesto m
                JOIN kinozal z ON m.id_zala=z.id_zala
                JOIN seans s ON s.id_zala=z.id_zala
                WHERE s.id_seansa=%s AND m.ryad=%s AND m.nomer_mesta=%s
            """, (seans_id, ryad, mesto_nomer))
            mesto = cursor.fetchone()
            if not mesto:
                return "Место не найдено"
            id_mesta = mesto[0]
            
            # Проверка, что место свободно (нет активных билетов на это место и сеанс)
            cursor.execute("""
                SELECT 1 FROM bilet 
                WHERE id_seansa=%s AND id_mesta=%s AND status='active'
            """, (seans_id, id_mesta))
            if cursor.fetchone():
                return "Это место уже занято"
            
            # ========== ШАГ 3: СОЗДАНИЕ БИЛЕТА ==========
            # Цена фиксированная 300 руб.
            cursor.execute("""
                INSERT INTO bilet (cena, status, id_seansa, id_mesta, id_clienta) 
                VALUES (300, 'active', %s, %s, %s)
            """, (seans_id, id_mesta, client_id))
            
            conn.commit()
            cursor.close()
            conn.close()
            
            # Возврат на панель пользователя
            role = session.get('role')
            if role == 'admin':
                return redirect('/admin_panel')
            elif role == 'kasir':
                return redirect('/kasir_panel')
            else:
                return redirect('/guest_panel')
        except Exception as e:
            # В случае ошибки откатываем изменения
            conn.rollback()
            return f'<h1>Ошибка при продаже билета: {e}</h1>'
    
    # GET запрос: показываем форму выбора сеанса
    conn = get_db_connection('guest', 'guest')
    if not conn:
        return "Ошибка подключения"
    
    cursor = conn.cursor()
    # Получаем список будущих сеансов для выпадающего списка
    cursor.execute("""
        SELECT s.id_seansa, f.nazvanie, to_char(s.data_vremya,'DD.MM.YYYY HH24:MI'), z.nazvanie_zala
        FROM seans s 
        JOIN film f ON s.id_filma=f.id_filma 
        JOIN kinozal z ON s.id_zala=z.id_zala
        WHERE s.data_vremya >= NOW() 
        ORDER BY s.data_vremya
    """)
    seansy = cursor.fetchall()
    cursor.close()
    conn.close()
    
    return render_template('buy_ticket.html', seansy=seansy)

# ВОЗВРАТ БИЛЕТА


@app.route('/return_ticket', methods=['GET', 'POST'])
@login_required
def return_ticket():
    """
    Возврат билета.
    
    Доступно всем авторизованным пользователям (admin, kasir, guest).
    
    GET: Показывает форму ввода телефона клиента
    POST (с телефоном): Поиск билетов по телефону и отображение списка
    POST (с ID билета): Возврат выбранного билета
    
    Алгоритм:
        1. Пользователь вводит телефон клиента
        2. Система показывает все активные билеты этого клиента
        3. Пользователь выбирает билет для возврата
        4. Статус билета меняется на 'returned'
    
    Возвращает:
        GET: HTML-страницу return_ticket.html (форма ввода телефона)
        POST: HTML-страницу со списком билетов или сообщение об успехе
    """
    if request.method == 'POST':
        # Случай 1: выбран конкретный билет для возврата
        if 'bileta_id' in request.form:
            conn = get_db_connection(session['user'], '')
            if not conn:
                return "Ошибка подключения"
            
            cursor = conn.cursor()
            # Меняем статус билета на 'returned'
            cursor.execute("UPDATE bilet SET status='returned' WHERE id_bileta=%s", (request.form['bileta_id'],))
            conn.commit()
            cursor.close()
            conn.close()
            
            # Возврат на панель пользователя
            role = session.get('role')
            if role == 'admin':
                return redirect('/admin_panel')
            elif role == 'kasir':
                return redirect('/kasir_panel')
            else:
                return redirect('/guest_panel')
        
        # Случай 2: введён телефон для поиска билетов
        elif 'telefon' in request.form:
            conn = get_db_connection(session['user'], '')
            if not conn:
                return "Ошибка подключения"
            
            telefon = request.form['telefon']
            cursor = conn.cursor()
            # Находим все активные билеты клиента
            cursor.execute("""
                SELECT b.id_bileta, f.nazvanie, to_char(s.data_vremya,'DD.MM.YYYY HH24:MI'), 
                       m.ryad, m.nomer_mesta, b.cena
                FROM bilet b
                JOIN seans s ON b.id_seansa=s.id_seansa
                JOIN film f ON s.id_filma=f.id_filma
                JOIN mesto m ON b.id_mesta=m.id_mesta
                JOIN client c ON b.id_clienta=c.id_clienta
                WHERE c.telefon=%s AND b.status='active'
                ORDER BY s.data_vremya
            """, (telefon,))
            tickets = cursor.fetchall()
            cursor.close()
            conn.close()
            
            return render_template('return_ticket.html', tickets=tickets, telefon=telefon)
    
    # GET запрос: показываем форму ввода телефона
    return render_template('return_ticket.html')

# ДОБАВЛЕНИЕ ФИЛЬМА (ТОЛЬКО ADMIN)


@app.route('/add_film', methods=['GET', 'POST'])
@login_required
def add_film():
    """
    Добавление нового фильма в прокат.
    
    Доступно только администратору.
    
    GET: Показывает форму добавления фильма
    POST: Сохраняет новый фильм в базу данных
    
    Возвращает:
        GET: HTML-страницу add_film.html
        POST: сообщение об успехе или ошибке
    """
    if session.get('role') != 'admin':
        return "Доступ запрещён", 403
    
    if request.method == 'POST':
        nazvanie = request.form['nazvanie']
        zhanr = request.form['zhanr']
        prodolzhitelnost = request.form['prodolzhitelnost']
        vozrastnoy_reiting = request.form.get('vozrastnoy_reiting') or '0+'
        
        conn = get_db_connection(session['user'], '')
        cursor = conn.cursor()
        try:
            cursor.execute("""
                INSERT INTO film (nazvanie, zhanr, prodolzhitelnost, vozrastnoy_reiting) 
                VALUES (%s, %s, %s, %s)
            """, (nazvanie, zhanr, prodolzhitelnost, vozrastnoy_reiting))
            conn.commit()
            cursor.close()
            conn.close()
            return '<h1>✅ Фильм успешно добавлен!</h1><a href="/admin_panel">Вернуться в панель администратора</a>'
        except Exception as e:
            conn.rollback()
            return f'<h1>❌ Ошибка: {e}</h1>'
    
    return render_template('add_film.html')

# ДОБАВЛЕНИЕ СЕАНСА (ТОЛЬКО ADMIN)


@app.route('/add_seans', methods=['GET', 'POST'])
@login_required
def add_seans():
    """
    Добавление нового сеанса в расписание.
    
    Доступно только администратору.
    
    GET: Показывает форму добавления сеанса (выбор фильма, зала, даты)
    POST: Сохраняет новый сеанс в базу данных
    
    Возвращает:
        GET: HTML-страницу add_seans.html с списками фильмов и залов
        POST: сообщение об успехе или ошибке
    """
    if session.get('role') != 'admin':
        return "Доступ запрещён", 403
    
    # Получаем списки фильмов и залов для выпадающих списков
    conn = get_db_connection(session['user'], '')
    cursor = conn.cursor()
    cursor.execute("SELECT id_filma, nazvanie FROM film ORDER BY id_filma")
    films = cursor.fetchall()
    cursor.execute("SELECT id_zala, nazvanie_zala FROM kinozal ORDER BY id_zala")
    halls = cursor.fetchall()
    cursor.close()
    conn.close()
    
    if request.method == 'POST':
        id_filma = request.form['id_filma']
        id_zala = request.form['id_zala']
        data_vremya = request.form['data_vremya']
        tip_pokaza = request.form.get('tip_pokaza') or '2D'
        
        conn = get_db_connection(session['user'], '')
        cursor = conn.cursor()
        try:
            cursor.execute("""
                INSERT INTO seans (data_vremya, tip_pokaza, id_filma, id_zala) 
                VALUES (%s, %s, %s, %s)
            """, (data_vremya, tip_pokaza, id_filma, id_zala))
            conn.commit()
            cursor.close()
            conn.close()
            return '<h1>✅ Сеанс успешно добавлен!</h1><a href="/admin_panel">Вернуться в панель администратора</a>'
        except Exception as e:
            conn.rollback()
            return f'<h1>❌ Ошибка: {e}</h1>'
    
    return render_template('add_seans.html', films=films, halls=halls)


# УДАЛЕНИЕ ФИЛЬМА (ТОЛЬКО ADMIN, ТОЛЬКО ЕСЛИ НЕТ БИЛЕТОВ)


@app.route('/delete_film', methods=['GET', 'POST'])
@login_required
def delete_film():
    """
    Удаление фильма из проката.
    
    Доступно только администратору.
    Удалить можно только фильм, на который НЕТ купленных билетов.
    
    GET: Показывает список фильмов с индикацией возможности удаления
    POST: Удаляет выбранный фильм (предварительно проверяя наличие билетов)
    
    Возвращает:
        GET: HTML-страницу delete_film.html
        POST: сообщение об успехе или ошибке
    """
    if session.get('role') != 'admin':
        return "Доступ запрещён", 403
    
    # Получаем список фильмов с информацией о наличии билетов
    conn = get_db_connection(session['user'], '')
    if not conn:
        return "Ошибка подключения к базе данных"
    
    cursor = conn.cursor()
    cursor.execute("""
        SELECT f.id_filma, f.nazvanie, 
               CASE WHEN COUNT(b.id_bileta) > 0 THEN '❌ Есть билеты' ELSE '✅ Можно удалить' END as status,
               COUNT(b.id_bileta) as tickets_count
        FROM film f
        LEFT JOIN seans s ON s.id_filma = f.id_filma
        LEFT JOIN bilet b ON b.id_seansa = s.id_seansa AND b.status = 'active'
        GROUP BY f.id_filma, f.nazvanie
        ORDER BY f.id_filma
    """)
    films = cursor.fetchall()
    cursor.close()
    conn.close()
    
    if request.method == 'POST':
        film_id = request.form['film_id']
        
        # Дополнительная проверка наличия билетов
        conn = get_db_connection(session['user'], '')
        if not conn:
            return "Ошибка подключения"
        
        cursor = conn.cursor()
        cursor.execute("""
            SELECT COUNT(b.id_bileta) 
            FROM bilet b
            JOIN seans s ON b.id_seansa = s.id_seansa
            WHERE s.id_filma = %s AND b.status = 'active'
        """, (film_id,))
        ticket_count = cursor.fetchone()[0]
        cursor.close()
        
        if ticket_count > 0:
            conn.close()
            return f'<h1>❌ НЕЛЬЗЯ УДАЛИТЬ ФИЛЬМ!</h1><p>На этот фильм уже куплено билетов: {ticket_count} шт.</p><p>Сначала верните или удалите все билеты.</p><a href="/delete_film">Назад к списку фильмов</a>'
        
        # Удаление фильма
        cursor = conn.cursor()
        try:
            cursor.execute("SELECT nazvanie FROM film WHERE id_filma = %s", (film_id,))
            film_name = cursor.fetchone()[0]
            
            # Сначала удаляем сеансы (они не имеют билетов, так как проверено)
            cursor.execute("DELETE FROM seans WHERE id_filma = %s", (film_id,))
            # Затем удаляем фильм
            cursor.execute("DELETE FROM film WHERE id_filma = %s", (film_id,))
            
            conn.commit()
            cursor.close()
            conn.close()
            return f'<h1>✅ Фильм "{film_name}" успешно удалён!</h1><p>Сеансы фильма также были удалены.</p><a href="/delete_film">Удалить ещё фильм</a><br><a href="/admin_panel">Вернуться в панель администратора</a>'
        except Exception as e:
            conn.rollback()
            return f'<h1>❌ Ошибка при удалении: {e}</h1>'
    
    return render_template('delete_film.html', films=films)


# ПРОСМОТР DML-ЛОГОВ (ИЗМЕНЕНИЯ ДАННЫХ) - ТОЛЬКО ADMIN

@app.route('/logs')
@login_required
def logs():
    """
    Просмотр журнала действий с данными (DML-логи).
    
    Доступно только администратору.
    Показывает все операции INSERT, UPDATE, DELETE из таблицы audit.logs.
    
    Триггеры записывают сюда каждое изменение данных в таблицах.
    
    Возвращает:
        HTML-страницу logs.html с списком логов
    """
    if session.get('role') != 'admin':
        return "Доступ запрещён", 403
    
    conn = get_db_connection(session['user'], '')
    if not conn:
        return "Ошибка подключения к базе данных"
    
    cursor = conn.cursor()
    # Выбираем последние 50 записей из логов, сортируем от новых к старым
    cursor.execute("""
        SELECT data_vremya, polzovatel, deystvie, tablica 
        FROM audit.logs 
        ORDER BY data_vremya DESC 
        LIMIT 50
    """)
    rows = cursor.fetchall()
    cursor.close()
    conn.close()
    
    return render_template('logs.html', logs=rows)

# ==================================================
# ПРОСМОТР DDL-ЛОГОВ (ИЗМЕНЕНИЯ СТРУКТУРЫ БД) - ТОЛЬКО ADMIN
# ==================================================

@app.route('/ddl_logs')
@login_required
def ddl_logs():
    """
    Просмотр журнала изменений структуры базы данных (DDL-логи).
    
    Доступно только администратору.
    Показывает операции CREATE TABLE, ALTER TABLE, DROP TABLE из таблицы audit.ddl_logs.
    
    Событийные триггеры (trg_ddl_audit и trg_drop_audit) записывают сюда изменения структуры.
    
    Возвращает:
        HTML-страницу ddl_logs.html с списком DDL-логов
    """
    if session.get('role') != 'admin':
        return "Доступ запрещён", 403
    
    conn = get_db_connection(session['user'], '')
    if not conn:
        return "Ошибка подключения"
    
    cursor = conn.cursor()
    cursor.execute("""
        SELECT data_vremya, polzovatel, deystvie, object_name, ddl_command
        FROM audit.ddl_logs
        ORDER BY data_vremya DESC
        LIMIT 50
    """)
    rows = cursor.fetchall()
    cursor.close()
    conn.close()
    
    return render_template('ddl_logs.html', ddl_logs=rows)


# ВЫПОЛНЕНИЕ DDL-КОМАНД (ДЛЯ ДЕМОНСТРАЦИИ ТРИГГЕРОВ) - ТОЛЬКО ADMIN


@app.route('/execute_ddl', methods=['GET', 'POST'])
@login_required
def execute_ddl():
    """
    Страница для выполнения DDL-команд.
    
    Доступно только администратору.
    Используется для демонстрации работы событийных триггеров.
    
    Позволяет выполнить CREATE TABLE, ALTER TABLE, DROP TABLE
    и сразу увидеть результат в DDL-логах.
    
    GET: Показывает форму ввода SQL-команды
    POST: Выполняет введённую команду и отображает результат
    
    Возвращает:
        GET: HTML-страницу execute_ddl.html
        POST: HTML-страницу с результатом выполнения
    """
    if session.get('role') != 'admin':
        return "Доступ запрещён", 403
    
    result = None
    error = None
    ddl_command = ""
    
    if request.method == 'POST':
        ddl_command = request.form['ddl_command']
        conn = get_db_connection(session['user'], '')
        if conn:
            cursor = conn.cursor()
            try:
                cursor.execute(ddl_command)
                conn.commit()
                result = "✅ Команда выполнена успешно! Триггер записал действие в audit.ddl_logs"
            except Exception as e:
                error = f"❌ Ошибка: {e}"
            finally:
                cursor.close()
                conn.close()
        else:
            error = "❌ Ошибка подключения к базе данных"
    
    return render_template('execute_ddl.html', result=result, error=error, ddl_command=ddl_command)


# ЗАПУСК ПРИЛОЖЕНИЯ

if __name__ == '__main__':
    """
    Точка входа в приложение.
    
    Запускает Flask-сервер в режиме отладки (debug=True).
    Сервер доступен по адресу http://127.0.0.1:5000
    """
    app.run(debug=True, host='127.0.0.1', port=5000)